import React from "react";

export default function Spacer() {
  return <div style={{ height: 20 }} />;
}
