export const DBNAME = "eaw"
