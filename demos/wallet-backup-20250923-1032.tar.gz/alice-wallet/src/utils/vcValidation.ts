import { VCValidationResult } from '../types/invitations';

// Safe base64 decoding with validation
export function safeBase64Decode(base64String: string): { isValid: boolean; data?: string; error?: string } {
  try {
    // Check if string looks like base64
    if (!base64String || typeof base64String !== 'string') {
      return { isValid: false, error: 'Invalid input: not a string' };
    }

    // Remove whitespace and check base64 pattern
    const cleanBase64 = base64String.trim();
    const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;

    if (!base64Pattern.test(cleanBase64)) {
      return { isValid: false, error: 'Invalid base64 format' };
    }

    // Attempt to decode
    const decoded = atob(cleanBase64);
    return { isValid: true, data: decoded };
  } catch (error) {
    return { isValid: false, error: `Base64 decode failed: ${error.message}` };
  }
}

// Safe JSON parsing of base64 encoded data
export function safeBase64ParseJSON(base64String: string, description: string = 'data'): { isValid: boolean; data?: any; error?: string } {
  const decodeResult = safeBase64Decode(base64String);
  if (!decodeResult.isValid) {
    return { isValid: false, error: `Failed to decode ${description}: ${decodeResult.error}` };
  }

  try {
    const parsed = JSON.parse(decodeResult.data);
    return { isValid: true, data: parsed };
  } catch (error) {
    return { isValid: false, error: `Failed to parse ${description} JSON: ${error.message}` };
  }
}

// Detect invitation format
export function detectInvitationFormat(invitationString: string): { format: 'url' | 'json' | 'base64' | 'unknown'; data?: string } {
  try {
    // Check if it's a URL
    if (invitationString.startsWith('http://') || invitationString.startsWith('https://')) {
      return { format: 'url', data: invitationString };
    }

    // Check if it's already JSON
    if (invitationString.trim().startsWith('{') || invitationString.trim().startsWith('[')) {
      JSON.parse(invitationString); // Validate JSON
      return { format: 'json', data: invitationString };
    }

    // Check if it's base64
    const decodeResult = safeBase64Decode(invitationString);
    if (decodeResult.isValid) {
      // Try to parse as JSON
      try {
        JSON.parse(decodeResult.data);
        return { format: 'base64', data: decodeResult.data };
      } catch {
        // Valid base64 but not JSON
        return { format: 'base64', data: decodeResult.data };
      }
    }

    return { format: 'unknown' };
  } catch {
    return { format: 'unknown' };
  }
}

export function validateVerifiableCredential(vcProof: any): VCValidationResult {
  const result: VCValidationResult = {
    isValid: false,
    errors: []
  };

  try {
    if (!vcProof) {
      result.errors.push('No VC proof provided');
      return result;
    }

    // Basic structure validation
    if (!vcProof.credentialSubject && !vcProof.claims) {
      result.errors.push('Missing credential subject or claims');
    }

    if (!vcProof.type) {
      result.errors.push('Missing credential type');
    }

    // Check if it's a RealPerson credential
    const hasRealPersonType = vcProof.type?.includes('RealPerson') ||
                             vcProof.credentialType === 'RealPerson';
    if (!hasRealPersonType) {
      result.errors.push('Not a RealPerson credential');
    }

    // Extract issuer information
    if (vcProof.issuer) {
      result.issuer = vcProof.issuer;
    }

    // Extract timestamps
    if (vcProof.issuanceDate) {
      result.issuedAt = vcProof.issuanceDate;
    }
    if (vcProof.expirationDate) {
      result.expiresAt = vcProof.expirationDate;
    }

    // Check if expired
    if (result.expiresAt) {
      const expiryDate = new Date(result.expiresAt);
      const now = new Date();
      if (expiryDate < now) {
        result.errors.push('Credential has expired');
      }
    }

    // For demo purposes, we'll consider it valid if no critical errors
    result.isValid = result.errors.length === 0;

    return result;
  } catch (error) {
    result.errors.push(`Validation error: ${error.message}`);
    return result;
  }
}

export function extractCredentialSubject(credential: any): any {
  // Try multiple paths to find credential subject data
  if (credential.credentialSubject) {
    return credential.credentialSubject;
  }

  if (credential.claims && Array.isArray(credential.claims) && credential.claims.length > 0) {
    const firstClaim = credential.claims[0];
    if (firstClaim.credentialSubject) {
      return firstClaim.credentialSubject;
    }
    if (firstClaim.credentialData?.credentialSubject) {
      return firstClaim.credentialData.credentialSubject;
    }
    return firstClaim;
  }

  if (credential.credentialData?.credentialSubject) {
    return credential.credentialData.credentialSubject;
  }

  // Fallback: look for person-like data anywhere in the credential
  const personFields = ['firstName', 'lastName', 'uniqueId', 'dateOfBirth'];
  for (const value of Object.values(credential)) {
    if (value && typeof value === 'object') {
      const hasPersonFields = personFields.some(field => field in value);
      if (hasPersonFields) {
        return value;
      }
    }
  }

  return {};
}

export function isCredentialRevoked(credential: any): boolean {
  // In a real implementation, this would check against a revocation registry
  // For demo purposes, we'll assume credentials are not revoked
  return false;
}

export function parseInviterIdentity(vcProof: any, validationResult: VCValidationResult): any {
  const identity = {
    isVerified: validationResult.isValid,
    revealedData: {},
    validationResult
  };

  if (validationResult.isValid) {
    // Extract revealed data from the VC proof
    const credentialSubject = extractCredentialSubject(vcProof);
    identity.revealedData = credentialSubject;
  }

  return identity;
}