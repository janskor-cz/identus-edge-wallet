import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { DisclosureLevel, DISCLOSURE_PRESETS, FIELD_LABELS } from '../types/invitations';
import { extractCredentialSubject } from '../utils/vcValidation';
import { getFieldsForDisclosureLevel, applySelectiveDisclosure } from '../utils/selectiveDisclosure';

interface SelectiveDisclosureProps {
  credential: any;
  onFieldSelection: (fields: string[], level: DisclosureLevel) => void;
  initialLevel?: DisclosureLevel;
}

export const SelectiveDisclosure: React.FC<SelectiveDisclosureProps> = ({
  credential,
  onFieldSelection,
  initialLevel = 'minimal'
}) => {
  const [selectedLevel, setSelectedLevel] = useState<DisclosureLevel>(initialLevel);
  const [customFields, setCustomFields] = useState<string[]>([]);
  const [isCustomMode, setIsCustomMode] = useState(false);

  const credentialSubject = useMemo(() => extractCredentialSubject(credential), [credential]);
  const availableFields = useMemo(() => Object.keys(credentialSubject), [credentialSubject]);

  // Stabilize the callback to prevent infinite re-renders
  const stableOnFieldSelection = useCallback(onFieldSelection, []);

  useEffect(() => {
    if (!isCustomMode) {
      const presetFields = getFieldsForDisclosureLevel(selectedLevel);
      const validFields = presetFields.filter(field => availableFields.includes(field));
      setCustomFields(validFields);
      stableOnFieldSelection(validFields, selectedLevel);
    }
  }, [selectedLevel, isCustomMode, availableFields, stableOnFieldSelection]);

  useEffect(() => {
    if (isCustomMode) {
      // Determine appropriate disclosure level based on custom field selection
      let customLevel: DisclosureLevel = 'minimal';

      // Match custom selection to appropriate preset level
      const minimalFields = DISCLOSURE_PRESETS.minimal.fields;
      const standardFields = DISCLOSURE_PRESETS.standard.fields;
      const fullFields = DISCLOSURE_PRESETS.full.fields;

      if (customFields.length >= fullFields.length && fullFields.every(field => customFields.includes(field))) {
        customLevel = 'full';
      } else if (customFields.length >= standardFields.length && standardFields.every(field => customFields.includes(field))) {
        customLevel = 'standard';
      } else {
        customLevel = 'minimal';
      }

      console.log(`🎛️ Custom field selection mapped to disclosure level: ${customLevel}`);
      stableOnFieldSelection(customFields, customLevel);
    }
  }, [customFields, isCustomMode, stableOnFieldSelection]);

  const handlePresetChange = (level: DisclosureLevel) => {
    console.log(`📋 Preset disclosure level selected: ${level}`);
    setSelectedLevel(level);
    setIsCustomMode(false);
  };

  const handleCustomFieldToggle = (field: string) => {
    setCustomFields(prev => {
      if (prev.includes(field)) {
        return prev.filter(f => f !== field);
      } else {
        return [...prev, field];
      }
    });
  };

  const getPreviewData = () => {
    const fieldsToShow = isCustomMode ? customFields : getFieldsForDisclosureLevel(selectedLevel);
    return applySelectiveDisclosure(credential, fieldsToShow);
  };

  const previewData = getPreviewData();

  return (
    <div className="selective-disclosure">
      <h3 className="text-lg font-semibold mb-4">🔒 Choose Information to Share</h3>

      {/* Disclosure Level Presets */}
      <div className="disclosure-presets mb-6">
        <h4 className="text-md font-medium mb-3">Preset Levels:</h4>
        <div className="space-y-2">
          {Object.entries(DISCLOSURE_PRESETS).map(([level, preset]) => (
            <label key={level} className="flex items-center space-x-3 cursor-pointer">
              <input
                type="radio"
                name="disclosureLevel"
                value={level}
                checked={selectedLevel === level && !isCustomMode}
                onChange={() => handlePresetChange(level as DisclosureLevel)}
                className="h-4 w-4 text-blue-600"
              />
              <div>
                <div className="font-medium">{preset.label}</div>
                <div className="text-sm text-gray-600">{preset.description}</div>
              </div>
            </label>
          ))}

          <label className="flex items-center space-x-3 cursor-pointer">
            <input
              type="radio"
              name="disclosureLevel"
              value="custom"
              checked={isCustomMode}
              onChange={() => setIsCustomMode(true)}
              className="h-4 w-4 text-blue-600"
            />
            <div>
              <div className="font-medium">Custom Selection</div>
              <div className="text-sm text-gray-600">Choose specific fields to share</div>
            </div>
          </label>
        </div>
      </div>

      {/* Custom Field Selection */}
      {isCustomMode && (
        <div className="custom-fields mb-6">
          <h4 className="text-md font-medium mb-3">Select Fields:</h4>
          <div className="space-y-2">
            {availableFields.map(field => (
              <label key={field} className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={customFields.includes(field)}
                  onChange={() => handleCustomFieldToggle(field)}
                  className="h-4 w-4 text-blue-600"
                />
                <span className="font-medium">
                  {FIELD_LABELS[field as keyof typeof FIELD_LABELS] || field}
                </span>
                <span className="text-sm text-gray-600">
                  ({credentialSubject[field]})
                </span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Preview Section */}
      <div className="preview-section">
        <h4 className="text-md font-medium mb-3">📋 Preview - What will be shared:</h4>
        <div className="bg-gray-50 border rounded-lg p-4">
          {Object.keys(previewData).length === 0 ? (
            <div className="text-gray-500 italic">No fields selected for sharing</div>
          ) : (
            <div className="space-y-2">
              {Object.entries(previewData).map(([field, value]) => (
                <div key={field} className="flex justify-between">
                  <span className="font-medium">
                    {FIELD_LABELS[field as keyof typeof FIELD_LABELS] || field}:
                  </span>
                  <span className="text-gray-700">{value}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Information Box */}
      <div className="info-box mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="text-sm text-blue-800">
          <strong>🔒 Privacy Note:</strong> Only the selected information will be included in your invitation.
          Hidden fields will not be visible to the recipient.
        </div>
      </div>
    </div>
  );
};