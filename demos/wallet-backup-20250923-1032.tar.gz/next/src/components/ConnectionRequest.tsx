import React, { useState } from 'react';
import SDK from '@hyperledger/identus-edge-agent-sdk';
import { useMountedApp } from '@/reducers/store';
import { refreshConnections } from '@/actions';

interface ConnectionRequestProps {
  message: SDK.Domain.Message;
  onRequestHandled?: () => void;
}

export const ConnectionRequest: React.FC<ConnectionRequestProps> = ({
  message,
  onRequestHandled
}) => {
  const app = useMountedApp();
  const [isProcessing, setIsProcessing] = useState(false);
  const [hasHandled, setHasHandled] = useState(false);

  // Parse the connection request body
  const getRequestDetails = () => {
    try {
      const body = typeof message.body === 'string' ? JSON.parse(message.body) : message.body;
      return {
        label: body.label || 'Unknown',
        goal: body.goal || 'Connect',
        goalCode: body.goal_code || 'connect'
      };
    } catch (e) {
      return {
        label: 'Unknown',
        goal: 'Connect',
        goalCode: 'connect'
      };
    }
  };

  const requestDetails = getRequestDetails();

  const handleAcceptRequest = async () => {
    if (!app.agent.instance || isProcessing || hasHandled) return;

    setIsProcessing(true);
    try {
      console.log('🤝 Accepting connection request from:', message.from?.toString());

      // Create Alice's response DID with mediator service endpoints
      const responseDID = await app.agent.instance.createNewPeerDID([], true);
      console.log('✅ Alice response DID created:', responseDID.toString().substring(0, 60) + '...');

      // Create connection response message
      const responseBody = {
        accept: ["didcomm/v2"],
        goal_code: "connect",
        goal: `Response to connection request`,
        label: requestDetails.label
      };

      // Ensure toDID is a proper DID object
      let toDID: SDK.Domain.DID;
      if (typeof message.from === 'string') {
        toDID = SDK.Domain.DID.fromString(message.from);
      } else if (message.from && typeof message.from === 'object' && 'toString' in message.from) {
        toDID = SDK.Domain.DID.fromString(message.from.toString());
      } else {
        throw new Error('Invalid DID in message.from field');
      }

      const responseMessage = new SDK.Domain.Message(
        JSON.stringify(responseBody),
        crypto.randomUUID(),
        SDK.ProtocolType.DidcommconnectionResponse,
        responseDID,
        toDID,
        [],
        message.id
      );

      console.log('📤 Sending connection response...');
      await app.agent.instance.sendMessage(responseMessage);

      // Create and store the DIDPair connection
      const didPair = new SDK.Domain.DIDPair(
        responseDID,  // Alice's DID (host)
        toDID,        // Bob's ephemeral DID (receiver)
        requestDetails.label  // 'name' field in DIDPair constructor
      );

      console.log('💾 Storing connection using connectionManager...');
      await app.agent.instance.connectionManager.addConnection(didPair);
      console.log('✅ Connection stored successfully');

      // Refresh connections state
      await app.dispatch(refreshConnections());

      setHasHandled(true);
      onRequestHandled?.();

    } catch (error) {
      console.error('❌ Failed to accept connection request:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRejectRequest = () => {
    setHasHandled(true);
    onRequestHandled?.();
  };

  const formatTime = (timestamp?: string): string => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  return (
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6 mb-4 shadow-lg">
      {/* Header */}
      <div className="flex items-center mb-4">
        <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mr-4">
          <span className="text-2xl">🤝</span>
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Connection Request
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {formatTime(message.createdTime)}
          </p>
        </div>
        <div className="px-3 py-1 bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-200 text-sm rounded-full">
          Pending
        </div>
      </div>

      {/* Request Details */}
      <div className="mb-6 space-y-3">
        <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
            <strong>From:</strong>
          </p>
          <p className="text-xs font-mono text-gray-800 dark:text-gray-200 break-all">
            {message.from?.toString()}
          </p>
        </div>

        <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
            <strong>Request:</strong>
          </p>
          <p className="text-sm text-gray-800 dark:text-gray-200">
            "{requestDetails.label}" wants to connect with you.
          </p>
          {requestDetails.goal && (
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Goal: {requestDetails.goal}
            </p>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      {!hasHandled && (
        <div className="flex space-x-3">
          <button
            onClick={handleAcceptRequest}
            disabled={isProcessing}
            className="flex-1 px-4 py-2 bg-green-500 hover:bg-green-600 disabled:bg-gray-400
                     text-white rounded-lg transition-colors duration-200
                     disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            {isProcessing ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin h-4 w-4 mr-2" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Accepting...
              </span>
            ) : (
              '🤝 Accept Connection'
            )}
          </button>
          <button
            onClick={handleRejectRequest}
            disabled={isProcessing}
            className="flex-1 px-4 py-2 bg-red-500 hover:bg-red-600 disabled:bg-gray-400
                     text-white rounded-lg transition-colors duration-200
                     disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            ❌ Reject Connection
          </button>
        </div>
      )}

      {hasHandled && (
        <div className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 p-3 rounded-lg text-center">
          Connection request handled
        </div>
      )}
    </div>
  );
};