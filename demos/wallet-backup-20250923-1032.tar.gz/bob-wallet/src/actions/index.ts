import { addRxPlugin } from "rxdb";
import { RxDBDevModePlugin } from "rxdb/plugins/dev-mode";

addRxPlugin(RxDBDevModePlugin);

import { AnyAction, ThunkDispatch, createAsyncThunk } from "@reduxjs/toolkit";
import SDK from "@hyperledger/identus-edge-agent-sdk";
import { sha512 } from '@noble/hashes/sha512'
import { RootState, reduxActions } from "@/reducers/app";
import IndexDB from '@pluto-encrypted/indexdb'
import { PresentationClaims } from "../../../../src/domain";


const Agent = SDK.Agent;
const BasicMessage = SDK.BasicMessage;
const OfferCredential = SDK.OfferCredential;
const ListenerKey = SDK.ListenerKey;
const IssueCredential = SDK.IssueCredential;
const RequestPresentation = SDK.RequestPresentation;


export const acceptPresentationRequest = createAsyncThunk<
    any,
    {
        agent: SDK.Agent,
        message: SDK.Domain.Message,
        credential: SDK.Domain.Credential
    }
>("acceptPresentationRequest", async (options, api) => {
    try {
        const { agent, message, credential } = options;
        const requestPresentation = RequestPresentation.fromMessage(message);
        try {
            const presentation = await agent.createPresentationForRequestProof(requestPresentation, credential);
            await agent.sendMessage(presentation.makeMessage());
        } catch (err) {
            console.log("continue after err", err);
        }
        return api.fulfillWithValue(null);
    } catch (err) {
        return api.rejectWithValue(err as Error);
    }
})

export const rejectPresentationRequest = createAsyncThunk<
    any,
    {
        message: SDK.Domain.Message,
        pluto: SDK.Domain.Pluto
    }
>("rejectPresentationRequest", async (options, api) => {
    try {
        const { message, pluto } = options;
        const requestPresentation = RequestPresentation.fromMessage(message);
        await pluto.deleteMessage(message.id)
        return api.fulfillWithValue(requestPresentation);
    } catch (err) {
        return api.rejectWithValue(err as Error);
    }
})

export const rejectCredentialOffer = createAsyncThunk<
    any,
    {
        message: SDK.Domain.Message,
        pluto: SDK.Domain.Pluto
    }
>("rejectCredentialOffer", async (options, api) => {
    try {
        const { message, pluto } = options;
        const credentialOffer = OfferCredential.fromMessage(message);
        await pluto.deleteMessage(message.id)
        return api.fulfillWithValue(credentialOffer);
    } catch (err) {
        return api.rejectWithValue(err as Error);
    }
})

export const acceptCredentialOffer = createAsyncThunk<
    any,
    {
        agent: SDK.Agent,
        message: SDK.Domain.Message
    }
>("acceptCredentialOffer", async (options, api) => {
    console.log('🚀 [DEBUG] acceptCredentialOffer function called with message ID:', options.message.id);
    console.log('🚀 [DEBUG] Message type:', options.message.piuri);
    try {
        const { agent, message } = options;
        console.log('🔍 [DEBUG] Parsing credential offer from message...');
        const credentialOffer = OfferCredential.fromMessage(message);
        console.log('🔍 [DEBUG] Credential offer parsed successfully:', {
            id: credentialOffer.id,
            thid: credentialOffer.thid,
            from: credentialOffer.from?.toString().substring(0, 40) + '...'
        });

        console.log('🔍 [DEBUG] Preparing credential request...');
        let requestCredential;
        try {
            requestCredential = await agent.prepareRequestCredentialWithIssuer(credentialOffer);
            console.log('🔍 [DEBUG] Credential request prepared successfully!');
        } catch (prepareError) {
            console.error('❌ [ERROR] Failed to prepare credential request:', prepareError);
            console.error('❌ [ERROR] Error type:', prepareError.constructor.name);
            console.error('❌ [ERROR] Error message:', prepareError.message);
            console.error('❌ [ERROR] Error stack:', prepareError.stack);

            // Log additional context
            console.log('🔍 [DEBUG] Agent state:', {
                isStarted: agent ? 'available' : 'null',
                agentDID: agent?.currentSeed ? 'has seed' : 'no seed'
            });

            // Debug: Check what methods are available on the agent
            const allMethods = Object.getOwnPropertyNames(Object.getPrototypeOf(agent));
            console.log('🔍 [DEBUG] Agent type:', agent.constructor.name);
            console.log('🔍 [DEBUG] Agent methods containing "credential":',
                allMethods.filter(name => name.toLowerCase().includes('credential'))
            );
            console.log('🔍 [DEBUG] Agent methods containing "prepare":',
                allMethods.filter(name => name.toLowerCase().includes('prepare'))
            );
            console.log('🔍 [DEBUG] All available agent methods:', allMethods.slice(0, 20)); // Show first 20 methods

            throw prepareError; // Re-throw to trigger the outer catch
        }
        try {
            const requestMessage = requestCredential.makeMessage()
            console.log('📤 Sending credential request message:', requestMessage.id);
            console.log('📤 Request message from:', requestMessage.from?.toString().substring(0, 60) + '...');
            console.log('📤 Request message to:', requestMessage.to?.toString().substring(0, 60) + '...');
            await agent.sendMessage(requestMessage);
            console.log('✅ Credential request sent successfully');

        // Debug: Check if message was stored in database
        try {
            const allMessages = await agent.pluto.getAllMessages();
            const recentMessages = allMessages.slice(-5); // Get last 5 messages
            console.log('🔍 [DEBUG] Recent messages in database:', recentMessages.map(m => ({
                id: m.id,
                piuri: m.piuri,
                from: m.from?.toString().substring(0, 40) + '...',
                to: m.to?.toString().substring(0, 40) + '...'
            })));
        } catch (debugErr) {
            console.log('🔍 [DEBUG] Could not fetch recent messages:', debugErr);
        }

        } catch (err) {
            console.error('❌ Failed to send credential request:', err);
            throw err; // Re-throw the error instead of silencing it
        }
        return api.fulfillWithValue(null);
    } catch (err) {
        return api.rejectWithValue(err as Error);
    }
})


async function handleMessages(
    options: {
        dispatch: ThunkDispatch<unknown, unknown, AnyAction>,
        agent: SDK.Agent,
    },
    newMessages: SDK.Domain.Message[]
) {
    const { agent, dispatch } = options;

    // Enhanced logging for all incoming messages
    console.log(`📨 [handleMessages] Processing ${newMessages.length} new messages`);
    newMessages.forEach((msg, idx) => {
        console.log(`📋 [handleMessages] Message ${idx + 1}:`, {
            id: msg.id,
            piuri: msg.piuri,
            from: msg.from?.toString()?.substring(0, 50) + '...',
            to: msg.to?.toString()?.substring(0, 50) + '...',
            createdTime: msg.createdTime
        });
    });

    // Filter connection responses and issued credentials
    const connectionResponses = newMessages.filter((message) =>
        message.piuri === "https://didcomm.org/didexchange/1.0/response" ||
        message.piuri === "https://didcomm.org/connections/1.0/response"
    );
    const issuedCredentials = newMessages.filter((message) => message.piuri === "https://didcomm.org/issue-credential/3.0/issue-credential");

    // Process connection responses first
    if (connectionResponses.length) {
        console.log(`🤝 [handleMessages] Found ${connectionResponses.length} connection response(s) to process`);

        for (const connectionResponse of connectionResponses) {
            try {
                console.log(`🔄 [handleMessages] Processing connection response ${connectionResponse.id}`);
                console.log(`   From: ${connectionResponse.from?.toString()?.substring(0, 60)}...`);
                console.log(`   To: ${connectionResponse.to?.toString()?.substring(0, 60)}...`);

                // Parse the connection response message
                const fromDID = connectionResponse.from; // Alice's DID
                const toDID = connectionResponse.to;     // Bob's DID

                if (!fromDID || !toDID) {
                    console.error('❌ [handleMessages] Invalid connection response: missing from or to DID');
                    continue;
                }

                console.log('✅ [handleMessages] Connection response received from Alice');
                console.log('🔄 [handleMessages] Triggering connection refresh...');
                dispatch(refreshConnections());
                console.log('✅ [handleMessages] Connection refresh dispatched');

            } catch (error) {
                console.error(`❌ [handleMessages] Failed to process connection response ${connectionResponse.id}:`, error);
            }
        }
    } else {
        console.log('ℹ️ [handleMessages] No connection responses found in this batch');
    }

    // Process issued credentials
    if (issuedCredentials.length) {
        console.log(`🎫 [handleMessages] Found ${issuedCredentials.length} issue-credential messages to process`);

        for (const issuedCredential of issuedCredentials) {
            try {
                console.log(`🔄 [handleMessages] Processing credential issuance for message ${issuedCredential.id}`);

                const issueCredential = IssueCredential.fromMessage(issuedCredential);
                console.log('✅ [handleMessages] IssueCredential message parsed successfully');

                console.log('🔧 [handleMessages] Calling agent.processIssuedCredentialMessage()...');
                const credential = await agent.processIssuedCredentialMessage(issueCredential);
                console.log('✅ [handleMessages] Credential processed successfully:', credential.id);

                console.log('📤 [handleMessages] Dispatching credentialSuccess to Redux store...');
                dispatch(
                    reduxActions.credentialSuccess(
                        credential
                    )
                );
                console.log('✅ [handleMessages] Credential added to Redux store successfully');

                // Trigger automatic credential refresh to update UI
                console.log('🔄 [handleMessages] Triggering automatic credential refresh...');
                dispatch(refreshCredentials());
                console.log('✅ [handleMessages] Automatic credential refresh dispatched');

            } catch (error) {
                console.error(`❌ [handleMessages] Failed to process credential for message ${issuedCredential.id}:`, error);
            }
        }
    } else {
        console.log('ℹ️ [handleMessages] No issue-credential messages found in this batch');
    }

    console.log('📤 [handleMessages] Dispatching messageSuccess for all messages...');
    dispatch(
        reduxActions.messageSuccess(
            newMessages
        )
    );
    console.log('✅ [handleMessages] All messages processed and added to store');
}

export const stopAgent = createAsyncThunk<
    { agent: SDK.Agent },
    { agent: SDK.Agent }
>("stopAgent", async (options, api) => {
    try {
        const { agent } = options
        agent.removeListener(ListenerKey.MESSAGE, handleMessages.bind({}, { dispatch: api.dispatch, agent }));
        await agent.stop()
        return api.fulfillWithValue({ agent })
    } catch (err) {
        return api.rejectWithValue(err as Error);
    }
})


export const startAgent = createAsyncThunk<
    { agent: SDK.Agent, selfDID: SDK.Domain.DID },
    { agent: SDK.Agent }
>("startAgent", async (options, api) => {
    try {
        const { agent } = options;
        agent.addListener(ListenerKey.MESSAGE, handleMessages.bind({}, { dispatch: api.dispatch, agent }));
        await agent.start()

        return api.fulfillWithValue({ agent, selfDID: await agent.createNewPeerDID([], true) })
    } catch (err) {
        return api.rejectWithValue(err as Error);
    }
})

export const sendMessage = createAsyncThunk<
    { message: SDK.Domain.Message },
    {
        agent: SDK.Agent,
        message: SDK.Domain.Message
    }
>('sendMessage', async (options, api) => {
    try {
        const { agent, message } = options;

        console.log('🔄 [Redux] Sending message via agent...');
        await agent.sendMessage(message);
        console.log('✅ [Redux] Message sent successfully');

        console.log('💾 [Redux] Storing message in local database...');
        // Try to store the message with retry logic for store insertion errors
        let storeAttempts = 0;
        const maxStoreAttempts = 3;

        while (storeAttempts < maxStoreAttempts) {
            try {
                await agent.pluto.storeMessage(message);
                console.log('✅ [Redux] Message stored successfully');
                break;
            } catch (storeError: any) {
                storeAttempts++;
                console.warn(`⚠️ [Redux] Store attempt ${storeAttempts} failed:`, storeError.message);

                if (storeAttempts >= maxStoreAttempts) {
                    console.error('❌ [Redux] Failed to store message after multiple attempts');
                    // Don't fail the entire action if message was sent successfully
                    // Just log the storage failure
                    console.warn('📤 [Redux] Message was sent but not stored locally');
                } else {
                    // Wait a bit before retrying
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
            }
        }

        // Always dispatch success to update UI, even if storage failed
        api.dispatch(
            reduxActions.messageSuccess(
                [message]
            )
        )
        return api.fulfillWithValue({ message });
    } catch (err) {
        console.error('❌ [Redux] sendMessage failed:', err);
        return api.rejectWithValue(err as Error);
    }
})

export const initiatePresentationRequest = createAsyncThunk<
    any,
    {
        agent: SDK.Agent,
        toDID: SDK.Domain.DID,
        presentationClaims: PresentationClaims<SDK.Domain.CredentialType>,
        type: SDK.Domain.CredentialType
    }
>("initiatePresentationRequest", async (options, api) => {
    try {
        const {
            agent,
            presentationClaims,
            toDID,
            type
        } = options;

        await agent.initiatePresentationRequest<typeof type>(
            type,
            toDID,
            presentationClaims
        );

        return api.fulfillWithValue(null)
    } catch (err) {
        return api.rejectWithValue(err as Error);
    }
})

//This is for demonstration purposes and assumes that
//The Cloud agent is running on port ::::::
//Resolver at some point will be configurable to run on specific universal resolver endpoints
//for testnet, mainnet switching, etc
class ShortFormDIDResolverSample implements SDK.Domain.DIDResolver {
    method: string = "prism"

    private async parseResponse(response: Response) {
        const data = await response.text();
        try {
            return JSON.parse(data);
        }
        catch {
            return data;
        }
    }

    async resolve(didString: string): Promise<SDK.Domain.DIDDocument> {
        const url = "http://localhost:8000/cloud-agent/dids/" + didString;
        const response = await fetch(url, {
            "headers": {
                "accept": "*/*",
                "accept-language": "en",
                "cache-control": "no-cache",
                "pragma": "no-cache",
                "sec-gpc": "1"
            },
            "method": "GET",
            "mode": "cors",
            "credentials": "omit"
        })
        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }
        const data = await response.json();
        const didDocument = data.didDocument;

        const servicesProperty = new SDK.Domain.Services(
            didDocument.service
        )
        const verificationMethodsProperty = new SDK.Domain.VerificationMethods(
            didDocument.verificationMethod
        )
        const coreProperties: SDK.Domain.DIDDocumentCoreProperty[] = [];
        const authenticate: SDK.Domain.Authentication[] = [];
        const assertion: SDK.Domain.AssertionMethod[] = [];

        for (const verificationMethod of didDocument.verificationMethod) {
            const isAssertion = didDocument.assertionMethod.find((method) => method === verificationMethod.id)
            if (isAssertion) {
                assertion.push(new SDK.Domain.AssertionMethod([isAssertion], [verificationMethod]))
            }
            const isAuthentication = didDocument.authentication.find((method) => method === verificationMethod.id)
            if (isAuthentication) {
                authenticate.push(new SDK.Domain.Authentication([isAuthentication], [verificationMethod]));
            }
        }

        coreProperties.push(...authenticate);
        coreProperties.push(servicesProperty);
        coreProperties.push(verificationMethodsProperty);

        const resolved = new SDK.Domain.DIDDocument(
            SDK.Domain.DID.fromString(didString),
            coreProperties
        );

        return resolved;
    }
}

export const initAgent = createAsyncThunk<
    { agent: SDK.Agent },
    {
        mediatorDID: SDK.Domain.DID,
        pluto: SDK.Domain.Pluto,
        defaultSeed: SDK.Domain.Seed
    }
>("initAgent", async (options, api) => {
    try {
        const { mediatorDID, pluto, defaultSeed } = options;

        const apollo = new SDK.Apollo();
        const extraResolvers = [
            ShortFormDIDResolverSample
        ];
        const castor = new SDK.Castor(apollo, extraResolvers)
        const agent = await Agent.initialize({
            apollo,
            castor,
            mediatorDID,
            pluto,
            seed: defaultSeed
        });
        return api.fulfillWithValue({
            agent,
        })
    } catch (err) {
        return api.rejectWithValue(err as Error);
    }
})

export const connectDatabase = createAsyncThunk<
    {
        db: SDK.Domain.Pluto
    },
    {
        encryptionKey: Uint8Array,
    },
    { state: { app: RootState } }
>("connectDatabase", async (options, api) => {
    try {
        const state = api.getState().app;
        const hashedPassword = sha512(options.encryptionKey)
        const apollo = new SDK.Apollo();
        const store = new SDK.Store({
            name: state.wallet.dbName, // Use wallet-specific database name
            storage: IndexDB,
            password: Buffer.from(hashedPassword).toString("hex")
        });
        const db = new SDK.Pluto(store, apollo);
        await db.start();
        const messages = await db.getAllMessages()
        const connections = await db.getAllDidPairs()
        const credentials = await db.getAllCredentials();
        api.dispatch(
            reduxActions.dbPreload(
                { messages, connections, credentials }
            )
        );
        return api.fulfillWithValue({ db });
    } catch (err) {
        return api.rejectWithValue(err as Error);
    }
});

export const refreshConnections = createAsyncThunk(
    'connections/refresh',
    async (_: void, api) => {
    try {
        const state = api.getState() as { app: { db: { instance: SDK.Domain.Pluto | null } } };
        const db = state.app.db.instance;

        console.log('🔄 RefreshConnections called');
        console.log('🔍 Database instance:', db ? 'available' : 'null');

        if (!db) {
            console.error('❌ Database not connected in refreshConnections');
            throw new Error("Database not connected");
        }

        console.log('📊 Fetching connections from database...');
        const connections = await db.getAllDidPairs();
        console.log(`✅ Found ${connections.length} connections in database:`, connections.map(c => ({
            alias: c.name || 'unnamed',
            host: c.host.toString().substring(0, 50) + '...',
            receiver: c.receiver.toString().substring(0, 50) + '...'
        })));

        console.log('🚀 Returning connections to Redux state');
        return { connections };
    } catch (err) {
        console.error('❌ RefreshConnections failed:', err);
        return api.rejectWithValue(err as Error);
    }
});

export const refreshCredentials = createAsyncThunk(
    'credentials/refresh',
    async (_: void, api) => {
    try {
        const state = api.getState() as { app: { db: { instance: SDK.Domain.Pluto | null } } };
        const db = state.app.db.instance;

        console.log('🔄 RefreshCredentials called');
        console.log('🔍 Database instance:', db ? 'available' : 'null');

        if (!db) {
            console.error('❌ Database not connected in refreshCredentials');
            throw new Error("Database not connected");
        }

        console.log('📊 Fetching credentials from database...');
        const credentials = await db.getAllCredentials();
        console.log(`✅ Found ${credentials.length} credentials in database:`);

        // Log each credential for debugging
        credentials.forEach((credential, index) => {
            console.log(`   ${index + 1}. Credential ID: ${credential.id}`);
            console.log(`      Type: ${credential.credentialType}`);
            console.log(`      Subject: ${credential.subject?.toString().substring(0, 40)}...`);
            if (credential.claims && credential.claims.length > 0) {
                console.log(`      Claims: ${credential.claims.length} claim(s)`);
                credential.claims.forEach((claim, claimIndex) => {
                    console.log(`         Claim ${claimIndex + 1}: ${JSON.stringify(claim).substring(0, 100)}...`);
                });
            }
        });

        console.log('🚀 Returning credentials to Redux state');
        return { credentials };
    } catch (err) {
        console.error('❌ RefreshCredentials failed:', err);
        return api.rejectWithValue(err as Error);
    }
});