import { VCValidationResult } from '../types/invitations';

// Safe base64 decoding with validation
export function safeBase64Decode(base64String: string): { isValid: boolean; data?: string; error?: string } {
  try {
    // Check if string looks like base64
    if (!base64String || typeof base64String !== 'string') {
      return { isValid: false, error: 'Invalid input: not a string' };
    }

    // Remove whitespace and check base64 pattern
    const cleanBase64 = base64String.trim();
    const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;

    if (!base64Pattern.test(cleanBase64)) {
      return { isValid: false, error: 'Invalid base64 format' };
    }

    // Attempt to decode
    const decoded = atob(cleanBase64);
    return { isValid: true, data: decoded };
  } catch (error) {
    return { isValid: false, error: `Base64 decode failed: ${error.message}` };
  }
}

// Safe JSON parsing of base64 encoded data
export function safeBase64ParseJSON(base64String: string, description: string = 'data'): { isValid: boolean; data?: any; error?: string } {
  const decodeResult = safeBase64Decode(base64String);
  if (!decodeResult.isValid) {
    return { isValid: false, error: `Failed to decode ${description}: ${decodeResult.error}` };
  }

  try {
    const parsed = JSON.parse(decodeResult.data);
    return { isValid: true, data: parsed };
  } catch (error) {
    return { isValid: false, error: `Failed to parse ${description} JSON: ${error.message}` };
  }
}

// Detect invitation format
export function detectInvitationFormat(invitationString: string): { format: 'url' | 'json' | 'base64' | 'unknown'; data?: string } {
  try {
    // Check if it's a URL
    if (invitationString.startsWith('http://') || invitationString.startsWith('https://')) {
      return { format: 'url', data: invitationString };
    }

    // Check if it's already JSON
    if (invitationString.trim().startsWith('{') || invitationString.trim().startsWith('[')) {
      JSON.parse(invitationString); // Validate JSON
      return { format: 'json', data: invitationString };
    }

    // Check if it's base64
    const decodeResult = safeBase64Decode(invitationString);
    if (decodeResult.isValid) {
      // Try to parse as JSON
      try {
        JSON.parse(decodeResult.data);
        return { format: 'base64', data: decodeResult.data };
      } catch {
        // Valid base64 but not JSON
        return { format: 'base64', data: decodeResult.data };
      }
    }

    return { format: 'unknown' };
  } catch {
    return { format: 'unknown' };
  }
}

export function validateVerifiableCredential(vcProof: any): VCValidationResult {
  const result: VCValidationResult = {
    isValid: false,
    errors: []
  };

  try {
    console.log('🔍 [VALIDATION] Starting VC proof validation...');
    console.log('🔍 [VALIDATION] vcProof exists:', !!vcProof);

    if (!vcProof) {
      result.errors.push('No VC proof provided');
      console.log('❌ [VALIDATION] No VC proof provided');
      return result;
    }

    // Check if this is a presentation definition request (DIF Presentation Exchange)
    const isPresentationRequest = vcProof.input_descriptors && vcProof.name && vcProof.purpose;
    console.log('🔍 [VALIDATION] Is presentation request:', isPresentationRequest);

    if (isPresentationRequest) {
      console.log('✅ [VALIDATION] Detected presentation definition request');

      // Validate presentation request structure
      if (!vcProof.input_descriptors || !Array.isArray(vcProof.input_descriptors)) {
        result.errors.push('Invalid presentation request: missing input descriptors');
        console.log('❌ [VALIDATION] Missing input descriptors');
      }

      // Check for challenge and domain in options
      if (!vcProof.options || !vcProof.options.challenge) {
        result.errors.push('Missing presentation challenge');
        console.log('❌ [VALIDATION] Missing presentation challenge');
      }

      if (!vcProof.options || !vcProof.options.domain) {
        result.errors.push('Missing presentation domain');
        console.log('❌ [VALIDATION] Missing presentation domain');
      }

      // Check if it's requesting RealPerson credentials
      const requestsRealPerson = vcProof.input_descriptors.some((desc: any) =>
        desc.name?.includes('RealPerson') || desc.id?.includes('realperson')
      );
      console.log('🔍 [VALIDATION] Requests RealPerson:', requestsRealPerson);

      if (!requestsRealPerson) {
        result.errors.push('Presentation request is not for RealPerson credentials');
        console.log('❌ [VALIDATION] Not requesting RealPerson credentials');
      }

      // Extract issuer info from example credential if available
      if (vcProof.example_credential && vcProof.example_credential.issuer) {
        result.issuer = vcProof.example_credential.issuer;
        console.log('✅ [VALIDATION] Found issuer in example credential:', result.issuer);
      }

    } else {
      console.log('🔍 [VALIDATION] Treating as direct VC credential');

      // Original VC validation logic for actual credentials
      console.log('🔍 [VALIDATION] Checking credentialSubject:', !!vcProof.credentialSubject);
      console.log('🔍 [VALIDATION] Checking claims:', !!vcProof.claims);
      if (!vcProof.credentialSubject && !vcProof.claims) {
        result.errors.push('Missing credential subject or claims');
        console.log('❌ [VALIDATION] Missing credential subject or claims');
      }

      console.log('🔍 [VALIDATION] Checking type:', vcProof.type);
      if (!vcProof.type) {
        result.errors.push('Missing credential type');
        console.log('❌ [VALIDATION] Missing credential type');
      }

      // Check if it's a RealPerson credential
      console.log('🔍 [VALIDATION] Checking RealPerson type...');
      console.log('🔍 [VALIDATION] vcProof.type:', vcProof.type);
      console.log('🔍 [VALIDATION] vcProof.credentialType:', vcProof.credentialType);
      const hasRealPersonType = vcProof.type?.includes('RealPerson') ||
                               vcProof.credentialType === 'RealPerson';
      console.log('🔍 [VALIDATION] hasRealPersonType:', hasRealPersonType);
      if (!hasRealPersonType) {
        result.errors.push('Not a RealPerson credential');
        console.log('❌ [VALIDATION] Not a RealPerson credential');
      }

      // Extract issuer information
      if (vcProof.issuer) {
        result.issuer = vcProof.issuer;
      }
    }

    // Extract timestamps (only for direct VCs, not presentation requests)
    if (!isPresentationRequest) {
      if (vcProof.issuanceDate) {
        result.issuedAt = vcProof.issuanceDate;
      }
      if (vcProof.expirationDate) {
        result.expiresAt = vcProof.expirationDate;
      }
    } else {
      // For presentation requests, use example credential dates if available
      if (vcProof.example_credential?.issuanceDate) {
        result.issuedAt = vcProof.example_credential.issuanceDate;
      }
      if (vcProof.example_credential?.expirationDate) {
        result.expiresAt = vcProof.example_credential.expirationDate;
      }
    }

    // Check if expired
    if (result.expiresAt) {
      const expiryDate = new Date(result.expiresAt);
      const now = new Date();
      if (expiryDate < now) {
        result.errors.push('Credential has expired');
      }
    }

    // For demo purposes, we'll consider it valid if no critical errors
    result.isValid = result.errors.length === 0;

    console.log('🔍 [VALIDATION] Final validation result:');
    console.log('🔍 [VALIDATION] Total errors:', result.errors.length);
    console.log('🔍 [VALIDATION] Errors:', result.errors);
    console.log('🔍 [VALIDATION] Is valid:', result.isValid);

    return result;
  } catch (error) {
    result.errors.push(`Validation error: ${error.message}`);
    return result;
  }
}

export function extractCredentialSubject(credential: any): any {
  // Check if this is a presentation request (has example_credential)
  if (credential.example_credential) {
    console.log('🔍 [EXTRACT] Extracting from example_credential in presentation request');
    return extractCredentialSubject(credential.example_credential);
  }

  // Try multiple paths to find credential subject data
  if (credential.credentialSubject) {
    console.log('✅ [EXTRACT] Found credentialSubject directly');
    return credential.credentialSubject;
  }

  if (credential.claims && Array.isArray(credential.claims) && credential.claims.length > 0) {
    console.log('🔍 [EXTRACT] Searching in claims array');
    const firstClaim = credential.claims[0];
    if (firstClaim.credentialSubject) {
      return firstClaim.credentialSubject;
    }
    if (firstClaim.credentialData?.credentialSubject) {
      return firstClaim.credentialData.credentialSubject;
    }
    return firstClaim;
  }

  if (credential.credentialData?.credentialSubject) {
    console.log('✅ [EXTRACT] Found in credentialData.credentialSubject');
    return credential.credentialData.credentialSubject;
  }

  // Fallback: look for person-like data anywhere in the credential
  const personFields = ['firstName', 'lastName', 'uniqueId', 'dateOfBirth'];
  for (const value of Object.values(credential)) {
    if (value && typeof value === 'object') {
      const hasPersonFields = personFields.some(field => field in value);
      if (hasPersonFields) {
        return value;
      }
    }
  }

  return {};
}

export function isCredentialRevoked(credential: any): boolean {
  // In a real implementation, this would check against a revocation registry
  // For demo purposes, we'll assume credentials are not revoked
  return false;
}

export function parseInviterIdentity(vcProof: any, validationResult: VCValidationResult): any {
  const identity = {
    isVerified: validationResult.isValid,
    revealedData: {},
    validationResult
  };

  if (validationResult.isValid) {
    // Extract revealed data from the VC proof
    const credentialSubject = extractCredentialSubject(vcProof);
    identity.revealedData = credentialSubject;
  }

  return identity;
}